import { Outlet, Link, useLocation } from 'react-router-dom';
import { useStore } from '../store';
import { LayoutDashboard, BedDouble, Calendar, Image as ImageIcon, Settings as SettingsIcon, LogOut, MonitorPlay, MessageSquare } from 'lucide-react';

export default function AdminLayout() {
  const logout = useStore(state => state.logout);
  const location = useLocation();

  const navItems = [
    { name: 'Dashboard', path: '/admin', icon: LayoutDashboard },
    { name: 'Rooms', path: '/admin/rooms', icon: BedDouble },
    { name: 'Bookings', path: '/admin/bookings', icon: Calendar },
    { name: 'Reviews', path: '/admin/reviews', icon: MessageSquare },
    { name: 'Gallery', path: '/admin/gallery', icon: ImageIcon },
    { name: 'Hero Images', path: '/admin/hero', icon: MonitorPlay },
    { name: 'Settings', path: '/admin/settings', icon: SettingsIcon },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex font-sans">
      <aside className="w-64 bg-[#151619] text-white flex flex-col fixed inset-y-0 shadow-xl overflow-y-auto">
        <div className="p-6">
          <h2 className="text-xl font-serif font-bold text-white mb-1">Hotel Admin</h2>
          <p className="text-xs text-white/50 uppercase tracking-widest">Master Panel</p>
        </div>
        
        <nav className="flex-1 py-4">
          <ul className="space-y-1 px-3">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <li key={item.path}>
                  <Link 
                    to={item.path} 
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-[#E4E3E0] text-[#151619] font-medium' 
                        : 'text-white/70 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <Icon size={18} />
                    <span className="text-sm">{item.name}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="p-4 border-t border-white/10">
          <button 
            onClick={logout}
            className="flex items-center gap-3 px-3 py-2 w-full rounded text-left text-sm text-red-400 hover:bg-red-400/10 transition-colors"
          >
            <LogOut size={18} />
            Logout
          </button>
        </div>
      </aside>

      <main className="flex-grow ml-64 p-8">
        <Outlet />
      </main>
    </div>
  );
}
