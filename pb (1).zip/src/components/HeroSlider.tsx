import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface FullScreenSliderProps {
  images: { id: string; url: string }[];
  interval?: number;
}

export default function HeroSlider({ images, interval = 4000 }: FullScreenSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (!images || images.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, interval);
    return () => clearInterval(timer);
  }, [images, interval]);

  if (!images || images.length === 0) return null;

  return (
    <div className="absolute inset-0 z-0 w-full h-full overflow-hidden">
      {images.map((img, index) => (
        <div 
          key={img.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            index === currentIndex ? 'opacity-60' : 'opacity-0'
          }`}
        >
          <img 
            src={img.url} 
            alt="Hero Background" 
            className="w-full h-full object-cover"
          />
        </div>
      ))}

      {images.length > 1 && (
        <>
          <button 
            onClick={() => setCurrentIndex((prev) => (prev - 1 + images.length) % images.length)}
            className="absolute left-6 top-1/2 -translate-y-1/2 z-20 w-12 h-12 flex items-center justify-center text-white/50 hover:text-white hover:bg-black/20 rounded-full transition-all"
          >
            <ChevronLeft size={32} />
          </button>
          <button 
            onClick={() => setCurrentIndex((prev) => (prev + 1) % images.length)}
            className="absolute right-6 top-1/2 -translate-y-1/2 z-20 w-12 h-12 flex items-center justify-center text-white/50 hover:text-white hover:bg-black/20 rounded-full transition-all"
          >
            <ChevronRight size={32} />
          </button>
        </>
      )}
    </div>
  );
}
