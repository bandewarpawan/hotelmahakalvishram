import React, { useState } from 'react';
import { useStore } from '../store';
import { Star, CheckCircle2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { t } from '../utils/translations';

export default function ReviewSection() {
  const { reviews, addReview, language } = useStore();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [rating, setRating] = useState(5);
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  // Show only approved reviews
  const approvedReviews = reviews.filter(r => r.status === 'Approved');

  // Calculate average rating
  const avgRating = approvedReviews.length > 0 
    ? (approvedReviews.reduce((sum, r) => sum + r.rating, 0) / approvedReviews.length).toFixed(1)
    : "0.0";

  const onSubmit = (data: any) => {
    addReview({
      name: data.name,
      rating,
      message: data.message
    });
    setIsSubmitted(true);
    reset();
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  return (
    <section className="py-24 bg-white relative z-20">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header & Stats */}
        <div className="flex flex-col items-center mb-16 text-center">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="h-px bg-[#c48632]/30 w-24"></div>
            <h2 className="text-4xl font-serif text-[#1c2331]">{t(language, 'reviews')}</h2>
            <div className="h-px bg-[#c48632]/30 w-24"></div>
          </div>
          <p className="text-lg text-[#1c2331]/60 mb-8">{language === 'en' ? 'What Our Guests Say' : 'हमारे अतिथि क्या कहते हैं'}</p>

          <div className="flex items-center gap-4 bg-[#fcfaf7] px-6 py-3 rounded-full border border-black/5 shadow-sm">
            <div className="flex text-[#c48632]">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={24} className={i < Math.round(Number(avgRating)) ? 'fill-current' : 'text-gray-300'} />
              ))}
            </div>
            <div className="font-serif text-2xl font-bold text-[#1c2331]">
              {avgRating} <span className="text-base font-sans text-black/60 font-normal">/ 5</span>
            </div>
            <div className="px-3 py-1 bg-black/5 rounded-full text-sm font-semibold text-[#1c2331]/70">
              {language === 'en' ? `Based on ${approvedReviews.length} reviews` : `${approvedReviews.length} समीक्षाओं के आधार पर`}
            </div>
          </div>
        </div>

        {/* Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Reviews Slider / List */}
          <div className="lg:col-span-2">
            {approvedReviews.length === 0 ? (
              <div className="h-full flex flex-col justify-center items-center p-12 bg-[#fcfaf7] border border-dashed border-black/10 rounded-xl">
                <Star size={48} className="text-gray-300 mb-4" />
                <p className="text-[#1c2331]/50 font-medium">{language === 'en' ? 'No reviews yet. Be the first to share your experience!' : 'अभी तक कोई समीक्षा नहीं। अपना अनुभव साझा करने वाले पहले व्यक्ति बनें!'}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {approvedReviews.slice(0, 4).map(review => (
                  <div key={review.id} className="bg-[#fcfaf7] p-8 rounded-xl border border-black/5 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center gap-4 mb-4">
                       <div className="w-12 h-12 rounded-full overflow-hidden border border-[#c48632]/20 shadow-sm shrink-0">
                         {/* Fallback avatar placeholder styling like the image */}
                         <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${review.name}&backgroundColor=c48632&textColor=ffffff`} alt={review.name} className="w-full h-full object-cover" />
                       </div>
                       <div>
                          <h4 className="font-bold text-[#1c2331]">{review.name}</h4>
                          <div className="flex text-[#c48632]">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} size={12} className={i < review.rating ? 'fill-current' : 'text-gray-300'} />
                            ))}
                          </div>
                       </div>
                    </div>
                    <p className="text-[#1c2331]/70 font-serif italic mb-2 relative z-10 line-clamp-3">
                      "{review.message}"
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Submit Review Form */}
          <div className="bg-[#fcfaf7] p-8 rounded-xl border border-[#c48632]/20 shadow-lg h-fit">
            <h3 className="text-2xl font-serif text-[#1c2331] mb-2">{language === 'en' ? 'Share your experience' : 'अपना अनुभव साझा करें'}</h3>
            <p className="text-[#1c2331]/60 text-sm mb-6">{language === 'en' ? "We'd love to hear about your stay with us." : "हम आपके प्रवास के बारे में सुनना पसंद करेंगे।"}</p>
            
            {isSubmitted ? (
              <div className="bg-white border border-[#c48632]/30 text-center p-8 rounded-xl shadow-sm">
                <CheckCircle2 size={40} className="text-[#c48632] mx-auto mb-4" />
                <h4 className="font-bold text-lg text-[#1c2331] mb-2">{language === 'en' ? 'Thank you!' : 'धन्यवाद!'}</h4>
                <p className="text-[#1c2331]/60 text-sm">{language === 'en' ? 'Your review has been submitted and is waiting for approval.' : 'आपकी समीक्षा सबमिट कर दी गई है और अनुमोदन की प्रतीक्षा कर रही है।'}</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-[#1c2331] uppercase mb-2">{language === 'en' ? 'Your Rating' : 'आपकी रेटिंग'}</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        className={`transition-colors ${star <= rating ? 'text-[#c48632]' : 'text-gray-200 hover:text-gray-300'}`}
                      >
                        <Star size={28} className="fill-current" />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1c2331] uppercase mb-1">{t(language, 'name')}</label>
                  <input 
                    {...register('name', { required: true })} 
                    className="w-full border p-3 rounded bg-white focus:outline-none focus:border-[#c48632] transition-colors"
                    placeholder={language === 'en' ? "Enter your name" : "अपना नाम दर्ज करें"}
                  />
                  {errors.name && <span className="text-red-500 text-xs mt-1">{language === 'en' ? 'Name is required' : 'नाम आवश्यक है'}</span>}
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1c2331] uppercase mb-1">{language === 'en' ? 'Your Review' : 'आपकी समीक्षा'}</label>
                  <textarea 
                    {...register('message', { required: true })} 
                    rows={4}
                    className="w-full border p-3 rounded bg-white focus:outline-none focus:border-[#c48632] transition-colors"
                    placeholder={language === 'en' ? "Tell us about your stay..." : "हमें अपने प्रवास के बारे में बताएं..."}
                  />
                  {errors.message && <span className="text-red-500 text-xs mt-1">{language === 'en' ? 'Message is required' : 'संदेश आवश्यक है'}</span>}
                </div>

                <div className="pt-2">
                  <button 
                    type="submit" 
                    className="w-full bg-[#1c2331] hover:bg-[#c48632] text-white py-3 rounded-md font-semibold tracking-wide text-sm transition-colors shadow-md"
                  >
                    {t(language, 'submitReview')}
                  </button>
                </div>
              </form>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}
