import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Maximize2, X } from 'lucide-react';

interface RoomImageSliderProps {
  images: string[];
  name: string;
}

export default function RoomImageSlider({ images, name }: RoomImageSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    if (!images || images.length <= 1 || isFullscreen) return;
    
    const timer = setInterval(() => {
      setCurrentIndex((prev) => {
        return (prev + 1) % images.length;
      });
    }, 4000); // 4-second auto slide
    
    return () => clearInterval(timer);
  }, [images.length, isFullscreen]);

  const handleNext = (e?: React.MouseEvent) => {
    e?.preventDefault();
    e?.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  const handlePrev = (e?: React.MouseEvent) => {
    e?.preventDefault();
    e?.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const toggleFullscreen = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsFullscreen(!isFullscreen);
  };

  if (!images || images.length === 0) {
    return <img src="https://via.placeholder.com/400x300" alt={name} className="w-full h-full object-cover" />;
  }

  const SliderContent = () => (
    <>
      <img 
        src={images[currentIndex]} 
        alt={name} 
        className={`w-full h-full object-cover transition-transform duration-700 ${!isFullscreen ? 'group-hover:scale-105' : ''}`}
      />
      
      {images.length > 1 && (
        <>
          <button 
            onClick={handlePrev}
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-[#1c2331]/40 hover:bg-[#c48632] text-white rounded-full p-2 backdrop-blur-sm transition-all shadow-lg z-10 opacity-0 group-hover:opacity-100"
          >
            <ChevronLeft size={16} />
          </button>
          <button 
            onClick={handleNext}
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-[#1c2331]/40 hover:bg-[#c48632] text-white rounded-full p-2 backdrop-blur-sm transition-all shadow-lg z-10 opacity-0 group-hover:opacity-100"
          >
            <ChevronRight size={16} />
          </button>
          
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
            {images.map((_, idx) => (
              <div 
                key={idx} 
                className={`h-1.5 rounded-full transition-all shadow-sm ${idx === currentIndex ? 'w-4 bg-white' : 'w-1.5 bg-white/50'}`}
              />
            ))}
          </div>
        </>
      )}

      <button 
        onClick={toggleFullscreen}
        className="absolute top-3 left-3 bg-[#1c2331]/40 hover:bg-[#c48632] text-white rounded p-1.5 backdrop-blur-sm transition-all z-10 opacity-0 group-hover:opacity-100 shadow-md"
      >
        <Maximize2 size={14} />
      </button>
    </>
  );

  return (
    <>
      <div className="relative w-full h-full overflow-hidden group/slider">
        <SliderContent />
      </div>

      {isFullscreen && (
        <div className="fixed inset-0 z-[100] bg-[#1c2331]/95 flex items-center justify-center backdrop-blur-sm p-4" onClick={(e) => { e.stopPropagation(); setIsFullscreen(false); }}>
          <button 
            onClick={toggleFullscreen} 
            className="absolute top-6 right-6 bg-white/10 hover:bg-red-500 text-white rounded-full p-3 backdrop-blur-sm transition-colors z-[110] shadow-xl flex items-center justify-center cursor-pointer"
          >
            <X size={32} />
          </button>
          
          <img src={images[currentIndex]} className="max-w-[90vw] max-h-[90vh] object-contain select-none rounded shadow-2xl" alt={name} onClick={e => e.stopPropagation()}/>
          
          {images.length > 1 && (
            <>
              <button 
                onClick={handlePrev}
                className="absolute left-6 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-[#c48632] text-white rounded-full p-4 backdrop-blur-sm transition-all shadow-lg z-[110]"
              >
                <ChevronLeft size={32} />
              </button>
              <button 
                onClick={handleNext}
                className="absolute right-6 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-[#c48632] text-white rounded-full p-4 backdrop-blur-sm transition-all shadow-lg z-[110]"
              >
                <ChevronRight size={32} />
              </button>
              
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-[110]">
                {images.map((_, idx) => (
                  <div 
                    key={idx} 
                    className={`h-2 rounded-full transition-all shadow-md ${idx === currentIndex ? 'w-6 bg-[#c48632]' : 'w-2 bg-white/50'}`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}
