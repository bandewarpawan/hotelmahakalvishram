import { Outlet, Link } from 'react-router-dom';
import { useStore } from '../store';
import { MapPin, Phone, MessageSquare, Globe } from 'lucide-react';
import { t } from '../utils/translations';

export default function Layout() {
  const { settings, language, setLanguage } = useStore();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  const currentHotelName = language === 'hi' && settings.hotelNameHi ? settings.hotelNameHi : settings.hotelName;
  const currentAddress = language === 'hi' && settings.addressHi ? settings.addressHi : settings.address;

  return (
    <div className="min-h-screen flex flex-col font-sans">
      <header className="bg-[#1c2331] text-white sticky top-0 z-50 shadow-md no-print">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <Link to="/" className="text-2xl font-serif font-bold text-white flex items-center gap-2">
            <span className="w-10 h-10 rounded-full bg-[#c48632] text-white flex items-center justify-center text-xl shadow-sm">M</span>
            <span className="hidden sm:inline">{currentHotelName}</span>
          </Link>
          
          <nav className="hidden md:flex gap-8 items-center">
            <Link to="/" className="text-sm tracking-wide uppercase hover:text-[#c48632] transition-colors">{t(language, 'home')}</Link>
            <Link to="/rooms" className="text-sm tracking-wide uppercase hover:text-[#c48632] transition-colors">{t(language, 'rooms')}</Link>
            
            <div className="flex items-center gap-2 text-[#c48632] ml-4 font-semibold text-sm bg-white/5 px-4 py-2 rounded-full border border-white/10">
              <Phone size={16} /> 
              <span>{settings.phone}</span>
            </div>

            <button onClick={toggleLanguage} className="flex items-center gap-1 hover:text-[#c48632] transition-colors bg-white/10 px-3 py-1.5 rounded-full text-xs font-bold tracking-wider">
              <Globe size={14} />
              {language === 'en' ? 'हिंदी' : 'EN'}
            </button>

            <Link to="/rooms" className="bg-[#c48632] hover:bg-[#a87127] text-white px-6 py-2.5 rounded-md shadow-md shadow-[#c48632]/20 font-semibold uppercase tracking-wider text-sm transition-all transform hover:-translate-y-0.5">
              {t(language, 'bookNow')}
            </Link>
          </nav>

          <div className="flex md:hidden items-center gap-4">
            <button onClick={toggleLanguage} className="flex items-center gap-1 hover:text-[#c48632] transition-colors bg-white/10 px-2 py-1.5 rounded-full text-xs font-bold tracking-wider">
              {language === 'en' ? 'हिंदी' : 'EN'}
            </button>
            <Link to="/rooms" className="bg-[#c48632] text-white px-4 py-2 rounded-md shadow-md shadow-[#c48632]/20 font-semibold text-sm transition-all whitespace-nowrap">
              {t(language, 'bookNow')}
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-grow bg-[#fcfaf7]">
        <Outlet />
      </main>

      <footer className="bg-[#1c2331] text-white py-16 no-print">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
             <Link to="/" className="text-2xl font-serif font-bold text-white flex items-center gap-2 mb-6">
              <span className="w-10 h-10 rounded-full bg-[#c48632] text-white flex items-center justify-center text-xl shadow-sm">M</span>
              <span>{currentHotelName}</span>
            </Link>
            <p className="text-white/60 mb-6 max-w-sm">{t(language, 'experienceBest')}</p>
          </div>
          <div>
            <h4 className="text-lg mb-6 uppercase tracking-widest text-[#c48632]">{t(language, 'contact')}</h4>
            <div className="space-y-4 text-white/80">
              <p className="flex items-center gap-3"><MapPin size={18} className="text-[#c48632]" /> {currentAddress}</p>
              <p className="flex items-center gap-3"><Phone size={18} className="text-[#c48632]" /> {settings.phone}</p>
            </div>
          </div>
          <div>
            <h4 className="text-lg mb-6 uppercase tracking-widest text-[#c48632]">{t(language, 'quickLinks')}</h4>
            <div className="flex flex-col gap-3 text-white/80">
              <Link to="/rooms" className="hover:text-white transition-colors">{t(language, 'ourRooms')}</Link>
              <Link to="/rooms" className="hover:text-white transition-colors">{t(language, 'bookNow')}</Link>
              <a 
                href={`https://wa.me/${settings.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(settings.whatsappMessage)}`}
                target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 hover:text-[#25D366] transition-colors mt-2 text-[#25D366] font-medium"
              >
                <Globe size={18} />
                {t(language, 'whatsappUs')}
              </a>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 border-t border-white/10 mt-12 pt-8 text-center text-sm text-white/40">
          <Link to="/admin" className="hover:text-white transition-colors" title="Admin Login">© {new Date().getFullYear()}</Link> {currentHotelName}. All rights reserved.
        </div>
      </footer>

      {/* Floating WhatsApp Button positioned closely as requested */}
      <a
        href={`https://wa.me/${settings.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(settings.whatsappMessage)}`}
        target="_blank" rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-[60] bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center animate-bounce"
        aria-label="Chat on WhatsApp"
      >
        <svg viewBox="0 0 24 24" width="32" height="32" fill="currentColor">
          <path d="M12.031 0C5.395 0 0 5.394 0 12.031c0 2.124.553 4.195 1.603 6.012L.15 23.364l5.474-1.436a11.963 11.963 0 006.407 1.84h.004c6.634 0 12.031-5.395 12.031-12.033C24.066 5.396 18.666 0 12.031 0zm0 21.782c-1.802 0-3.558-.484-5.1-1.398l-.365-.216-3.791.994.998-3.69-.236-.376A9.972 9.972 0 012.022 12.03c0-5.528 4.5-10.027 10.03-10.027 5.527 0 10.027 4.5 10.027 10.028 0 5.527-4.5 10.027-10.027 10.027zm5.503-7.518c-.302-.151-1.787-.881-2.064-.981-.277-.101-.479-.151-.681.151-.202.302-.78 1.002-.957 1.203-.176.202-.353.227-.655.076-.302-.15-1.275-.47-2.428-1.5-1.01-.904-1.691-2.022-1.892-2.324-.201-.302-.021-.465.13-.616.136-.135.302-.353.453-.529.151-.176.201-.302.302-.503.1-.202.05-.378-.025-.53-.075-.15-.681-1.642-.933-2.246-.245-.589-.494-.509-.681-.518-.176-.008-.378-.008-.58-.008-.201 0-.529.076-.806.378-.277.302-1.058 1.033-1.058 2.518s1.083 2.922 1.234 3.123c.151.202 2.132 3.256 5.166 4.565 2.19 1.34 2.923 1.08 3.427.98.504-.101 1.787-.73 2.039-1.436.252-.705.252-1.31.176-1.436-.075-.126-.277-.202-.579-.353z"/>
        </svg>
      </a>
    </div>
  );
}
