import { useEffect, useRef } from 'react';
import { db } from './firebase';
import { collection, onSnapshot, doc, getDoc, setDoc } from 'firebase/firestore';
import { useStore, defaultRooms, defaultReviews, defaultHeroImages, defaultGallery } from './store';

export function useFirebaseSync() {
  const { setRooms, setBookings, setReviews, setHeroImages, setGallery, setStoreSettings } = useStore(state => state);
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    let unsubs: (() => void)[] = [];

    const initializeDataAndSubscribe = async () => {
      // 1. One-time Setup Check
      // If the global settings doc doesn't exist, we assume it's a completely blank database.
      // We will populate it with default template data *once*.
      const settingsDocRef = doc(db, 'settings', 'global');
      const settingsSnap = await getDoc(settingsDocRef);
      
      if (!settingsSnap.exists()) {
        const { settings } = useStore.getState();
        await setDoc(settingsDocRef, settings);
        
        defaultRooms.forEach(room => setDoc(doc(db, 'rooms', room.id), room));
        defaultReviews.forEach(review => setDoc(doc(db, 'reviews', review.id), review));
        defaultHeroImages.forEach(img => setDoc(doc(db, 'heroImages', img.id), img));
        defaultGallery.forEach(img => setDoc(doc(db, 'gallery', img.id), img));
      }

      // 2. Realtime Subscriptions
      const unrooms = onSnapshot(collection(db, 'rooms'), (snapshot) => {
        setRooms(snapshot.docs.map(doc => doc.data()));
      });
      unsubs.push(unrooms);

      const unbookings = onSnapshot(collection(db, 'bookings'), (snapshot) => {
        setBookings(snapshot.docs.map(doc => doc.data()));
      });
      unsubs.push(unbookings);

      const unreviews = onSnapshot(collection(db, 'reviews'), (snapshot) => {
        setReviews(snapshot.docs.map(doc => doc.data()));
      });
      unsubs.push(unreviews);

      const unhero = onSnapshot(collection(db, 'heroImages'), (snapshot) => {
        setHeroImages(snapshot.docs.map(doc => doc.data()));
      });
      unsubs.push(unhero);

      const ungallery = onSnapshot(collection(db, 'gallery'), (snapshot) => {
        setGallery(snapshot.docs.map(doc => doc.data()));
      });
      unsubs.push(ungallery);

      const unsettings = onSnapshot(doc(db, 'settings', 'global'), (docSnap) => {
        if (docSnap.exists()) {
          setStoreSettings(docSnap.data() as any);
        }
      });
      unsubs.push(unsettings);
    };

    initializeDataAndSubscribe();

    return () => {
      unsubs.forEach(unsub => unsub());
    };
  }, [setRooms, setBookings, setReviews, setHeroImages, setGallery, setStoreSettings]);
}
