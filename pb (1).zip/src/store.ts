import { create } from 'zustand';
import { db, auth } from './firebase';
import { doc, setDoc, deleteDoc, updateDoc, collection } from 'firebase/firestore';
import { signOut } from 'firebase/auth';

export interface Room {
  id: string;
  name: string;
  nameHi?: string;
  price: number;
  description: string;
  descriptionHi?: string;
  size: string;
  amenities: string[];
  amenitiesHi?: string[];
  images: string[];
  status: 'Available' | 'Booked';
}

export interface Booking {
  id: string;
  roomId: string;
  customerName: string;
  phone: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  roomIdStr: string;
  status: 'Pending' | 'Confirmed' | 'Cancelled';
  createdAt: string;
}

export interface Review {
  id: string;
  name: string;
  rating: number;
  message: string;
  date: string;
  status: 'Pending' | 'Approved' | 'Rejected';
}

export interface Settings {
  hotelName: string;
  hotelNameHi?: string;
  address: string;
  addressHi?: string;
  phone: string;
  whatsappMessage: string;
  ticketSystemEnabled: boolean;
}

interface AppState {
  language: 'en' | 'hi';
  setLanguage: (lang: 'en' | 'hi') => void;

  isAdminLoggedIn: boolean;
  setAdminStatus: (status: boolean) => void;
  logout: () => void;
  
  heroImages: { id: string; url: string }[];
  setHeroImages: (images: any[]) => void;
  addHeroImage: (url: string) => void;
  deleteHeroImage: (id: string) => void;

  rooms: Room[];
  setRooms: (rooms: any[]) => void;
  addRoom: (room: Omit<Room, 'id'>) => void;
  updateRoom: (id: string, room: Partial<Room>) => void;
  deleteRoom: (id: string) => void;

  bookings: Booking[];
  setBookings: (bookings: any[]) => void;
  addBooking: (booking: Omit<Booking, 'id' | 'createdAt' | 'status'>) => string;
  updateBookingStatus: (id: string, status: Booking['status']) => void;
  deleteBooking: (id: string) => void;

  gallery: { id: string; url: string; caption: string; captionHi?: string }[];
  setGallery: (gallery: any[]) => void;
  addPhoto: (url: string, caption: string, captionHi?: string) => void;
  deletePhoto: (id: string) => void;

  reviews: Review[];
  setReviews: (reviews: any[]) => void;
  addReview: (review: Omit<Review, 'id' | 'date' | 'status'>) => void;
  updateReviewStatus: (id: string, status: Review['status']) => void;
  deleteReview: (id: string) => void;

  settings: Settings;
  setStoreSettings: (settings: Settings) => void;
  updateSettings: (settings: Partial<Settings>) => void;
}

export const defaultReviews: Review[] = [
  { id: '1', name: 'Rahul Sharma', rating: 5, message: 'Excellent stay! The location near Mahakal Mandir is perfect. Very clean rooms.', date: '2026-04-10T10:30:00Z', status: 'Approved' },
  { id: '2', name: 'Priya Patel', rating: 4, message: 'Great ambience and cooperative staff. Loved the amenities. Will visit again.', date: '2026-04-12T14:20:00Z', status: 'Approved' },
  { id: '3', name: 'Amit Verma', rating: 5, message: 'Very comfortable and pure luxury. Highly recommended for family trips!', date: '2026-04-15T09:15:00Z', status: 'Approved' }
];

export const defaultHeroImages = [
  { id: '1', url: 'https://images.unsplash.com/photo-1542314831-c6a4d14b4c37?q=80&w=2070&auto=format&fit=crop' },
  { id: '2', url: 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?q=80&w=2049&auto=format&fit=crop' },
  { id: '3', url: 'https://images.unsplash.com/photo-1522798514-97ceb8c4f1c8?q=80&w=2070&auto=format&fit=crop' }
];

export const defaultRooms: Room[] = [
  {
    id: '1',
    name: 'Royal Suite',
    nameHi: 'रॉयल सुइट',
    price: 5000,
    description: 'Experience ultimate luxury in our Royal Suite with city views.',
    descriptionHi: 'शहर के नज़ारों के साथ हमारे रॉयल सुइट में बेहतरीन लक्ज़री का अनुभव करें।',
    size: '450 sq ft',
    amenities: ['AC', 'Free WiFi', 'King Bed', 'City View', 'Mini Bar'],
    amenitiesHi: ['एसी', 'फ्री वाई-फाई', 'किंग बेड', 'सिटी व्यू', 'मिनी बार'],
    images: [
      'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=2070&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1598928636135-d146006ff4be?q=80&w=2070&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1552566626-52f8b828add9?q=80&w=2070&auto=format&fit=crop'
    ],
    status: 'Available'
  },
  {
    id: '2',
    name: 'Deluxe Room',
    nameHi: 'डीलक्स रूम',
    price: 2500,
    description: 'Comfortable and elegant room for a perfect stay.',
    descriptionHi: 'एक आदर्श प्रवास के लिए आरामदायक और सुरुचिपूर्ण कमरा।',
    size: '300 sq ft',
    amenities: ['AC', 'Free WiFi', 'Queen Bed', 'Smart TV'],
    amenitiesHi: ['एसी', 'फ्री वाई-फाई', 'क्वीन बेड', 'स्मार्ट टीवी'],
    images: [
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?q=80&w=1974&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1566665797739-1674de7a421a?q=80&w=1974&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=2070&auto=format&fit=crop'
    ],
    status: 'Available'
  },
  {
    id: '3',
    name: 'Standard Room',
    nameHi: 'स्टैंडर्ड रूम',
    price: 1500,
    description: 'Essential comfort for budget-conscious travelers.',
    descriptionHi: 'बजट के प्रति जागरूक यात्रियों के लिए आवश्यक आराम।',
    size: '200 sq ft',
    amenities: ['AC', 'Double Bed', 'Attached Bath'],
    amenitiesHi: ['एसी', 'डबल बेड', 'अटैच्ड बाथ'],
    images: [
      'https://images.unsplash.com/photo-1598928506311-c55dd580e5cb?q=80&w=2070&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?q=80&w=2070&auto=format&fit=crop'
    ],
    status: 'Available'
  }
];

export const defaultGallery = [
  { id: '1', url: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=2070&auto=format&fit=crop', caption: 'Hotel Exterior', captionHi: 'होटल के बाहर का दृश्य' },
  { id: '2', url: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=2070&auto=format&fit=crop', caption: 'Lobby area', captionHi: 'लॉबी क्षेत्र' },
  { id: '3', url: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?q=80&w=2070&auto=format&fit=crop', caption: 'Luxury Pool', captionHi: 'लक्ज़री पूल' }
];

export const useStore = create<AppState>()(
  (set, get) => ({
    language: 'en',
    setLanguage: (lang) => set({ language: lang }),

    isAdminLoggedIn: false,
    setAdminStatus: (status) => set({ isAdminLoggedIn: status }),
    logout: async () => {
      await signOut(auth);
      set({ isAdminLoggedIn: false });
    },

    heroImages: defaultHeroImages,
    setHeroImages: (images) => set({ heroImages: images }),
    addHeroImage: async (url) => {
      const id = Date.now().toString();
      const newImg = { id, url };
      set((state) => ({ heroImages: [...state.heroImages, newImg] }));
      await setDoc(doc(db, 'heroImages', id), newImg);
    },
    deleteHeroImage: async (id) => {
      set((state) => ({ heroImages: state.heroImages.filter(img => img.id !== id) }));
      await deleteDoc(doc(db, 'heroImages', id));
    },

    rooms: defaultRooms,
    setRooms: (rooms) => set({ rooms }),
    addRoom: async (room) => {
      const id = Date.now().toString();
      const newRoom = { id, ...room };
      set((state) => ({ rooms: [...state.rooms, newRoom as Room] }));
      await setDoc(doc(db, 'rooms', id), newRoom);
    },
    updateRoom: async (id, updated) => {
      set((state) => ({ rooms: state.rooms.map(r => r.id === id ? { ...r, ...updated } : r) }));
      await updateDoc(doc(db, 'rooms', id), updated);
    },
    deleteRoom: async (id) => {
      set((state) => ({ rooms: state.rooms.filter(r => r.id !== id) }));
      await deleteDoc(doc(db, 'rooms', id));
    },

    bookings: [],
    setBookings: (bookings) => set({ bookings }),
    addBooking: (booking) => {
      const id = 'BKG' + Math.floor(Math.random() * 1000000);
      const newBooking = { ...booking, id, status: 'Pending', createdAt: new Date().toISOString() };
      set((state) => ({ bookings: [newBooking as Booking, ...state.bookings] }));
      setDoc(doc(db, 'bookings', id), newBooking);
      return id;
    },
    updateBookingStatus: async (id, status) => {
      set((state) => ({ bookings: state.bookings.map(b => b.id === id ? { ...b, status } : b) }));
      await updateDoc(doc(db, 'bookings', id), { status });
    },
    deleteBooking: async (id) => {
      set((state) => ({ bookings: state.bookings.filter(b => b.id !== id) }));
      await deleteDoc(doc(db, 'bookings', id));
    },

    gallery: defaultGallery,
    setGallery: (gallery) => set({ gallery }),
    addPhoto: async (url, caption, captionHi) => {
      const id = Date.now().toString();
      const newPhoto = { id, url, caption, captionHi: captionHi || null };
      set((state) => ({ gallery: [...state.gallery, newPhoto as any] }));
      await setDoc(doc(db, 'gallery', id), newPhoto);
    },
    deletePhoto: async (id) => {
      set((state) => ({ gallery: state.gallery.filter(p => p.id !== id) }));
      await deleteDoc(doc(db, 'gallery', id));
    },

    reviews: defaultReviews,
    setReviews: (reviews) => set({ reviews }),
    addReview: async (review) => {
      const id = Date.now().toString();
      const newReview = { ...review, id, date: new Date().toISOString(), status: 'Pending' };
      set((state) => ({ reviews: [newReview as Review, ...state.reviews] }));
      await setDoc(doc(db, 'reviews', id), newReview);
    },
    updateReviewStatus: async (id, status) => {
      set((state) => ({ reviews: state.reviews.map(r => r.id === id ? { ...r, status } : r) }));
      await updateDoc(doc(db, 'reviews', id), { status });
    },
    deleteReview: async (id) => {
      set((state) => ({ reviews: state.reviews.filter(r => r.id !== id) }));
      await deleteDoc(doc(db, 'reviews', id));
    },

    settings: {
      hotelName: 'Hotel Mahakal Vishram',
      hotelNameHi: 'होटल महाकाल विश्राम',
      address: 'Mahakal Mandir Road, Ujjain, MP',
      addressHi: 'महाकाल मंदिर रोड, उज्जैन, मध्य प्रदेश',
      phone: '+91 72475 75001',
      whatsappMessage: 'Hello, I want to inquire about a booking at Hotel Mahakal Vishram.',
      ticketSystemEnabled: true
    },
    setStoreSettings: (settings) => set({ settings }),
    updateSettings: async (newSettings) => {
      const currentSettings = get().settings;
      const combined = { ...currentSettings, ...newSettings };
      await setDoc(doc(db, 'settings', 'global'), combined, { merge: true });
    },
  })
);

