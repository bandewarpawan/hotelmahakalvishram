import React from 'react';
import { useStore, Review } from '../../store';
import { Check, X, Trash2, Star } from 'lucide-react';

export default function AdminReviews() {
  const { reviews, updateReviewStatus, deleteReview } = useStore();

  const handleStatusChange = (id: string, status: Review['status']) => {
    updateReviewStatus(id, status);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to completely delete this review?')) {
      deleteReview(id);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-serif text-[#1a1a1a] mb-8">Reviews Management</h1>

      <div className="bg-white rounded-xl shadow-sm border border-black/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-black/10">
                <th className="p-4 font-semibold text-sm text-black/70">Date</th>
                <th className="p-4 font-semibold text-sm text-black/70">Guest Details</th>
                <th className="p-4 font-semibold text-sm text-black/70 w-1/3">Review Message</th>
                <th className="p-4 font-semibold text-sm text-black/70">Rating</th>
                <th className="p-4 font-semibold text-sm text-black/70">Status</th>
                <th className="p-4 font-semibold text-sm text-black/70 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5">
              {reviews.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-black/50">
                    No reviews available.
                  </td>
                </tr>
              ) : (
                reviews.map(review => (
                  <tr key={review.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="p-4 text-sm text-black/60 font-medium">
                      {new Date(review.date).toLocaleDateString()}
                    </td>
                    <td className="p-4">
                      <div className="font-semibold text-sm">{review.name}</div>
                    </td>
                    <td className="p-4 hidden sm:table-cell">
                      <p className="text-sm text-black/70 line-clamp-2" title={review.message}>
                        "{review.message}"
                      </p>
                    </td>
                    <td className="p-4">
                      <div className="flex text-[#D4AF37]">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} size={14} className={i < review.rating ? 'fill-current' : 'text-gray-300'} />
                        ))}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={`inline-flex px-2 py-1 text-xs font-bold rounded-full ${
                        review.status === 'Approved' ? 'bg-green-100 text-green-800' :
                        review.status === 'Rejected' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {review.status}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex justify-end gap-2">
                        {review.status !== 'Approved' && (
                          <button
                            onClick={() => handleStatusChange(review.id, 'Approved')}
                            className="p-1.5 bg-green-50 text-green-600 hover:bg-green-100 rounded transition-colors"
                            title="Approve"
                          >
                            <Check size={16} />
                          </button>
                        )}
                        {review.status !== 'Rejected' && (
                          <button
                            onClick={() => handleStatusChange(review.id, 'Rejected')}
                            className="p-1.5 bg-yellow-50 text-yellow-600 hover:bg-yellow-100 rounded transition-colors"
                            title="Reject"
                          >
                            <X size={16} />
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(review.id)}
                          className="p-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded transition-colors"
                          title="Delete"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
