import React, { useState } from 'react';
import { useStore } from '../../store';
import { Plus, Trash2, X } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { compressImage } from '../../utils/imageUtils';

export default function AdminHero() {
  const { heroImages, addHeroImage, deleteHeroImage } = useStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  
  const { handleSubmit, reset } = useForm();

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    setIsUploading(true);
    try {
      const dataUrl = await compressImage(e.target.files[0], 1920); // Keep high res for hero
      setImagePreview(dataUrl);
    } catch (error) {
      console.error("Error compressing image", error);
    }
    setIsUploading(false);
  };

  const onSubmit = () => {
    if (!imagePreview) {
      alert("Please select an image to upload");
      return;
    }
    addHeroImage(imagePreview);
    reset();
    setImagePreview('');
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this hero image? It will be removed from the Home Page slider immediately.')) {
      deleteHeroImage(id);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-serif text-[#1a1a1a]">Hero Slider Management</h1>
        <button 
          onClick={() => {
            setImagePreview('');
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 bg-[#1a1a1a] text-white px-4 py-2 rounded text-sm font-semibold hover:bg-black transition-colors"
        >
          <Plus size={16} /> Add Hero Image
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {heroImages.map((photo, index) => (
          <div key={photo.id} className="relative group bg-white p-2 rounded-xl border border-black/10">
            <div className="aspect-video relative overflow-hidden rounded-lg">
              <img src={photo.url} alt={`Hero ${index}`} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button 
                  onClick={() => handleDelete(photo.id)}
                  className="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-red-700 transition"
                  title="Delete Photo"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
            <p className="mt-2 text-sm text-center font-medium text-black/70">Slide {index + 1}</p>
          </div>
        ))}
      </div>
      
      {heroImages.length === 0 && (
         <div className="text-center py-16 text-black/50 border border-dashed rounded-xl bg-black/5">
           No images in Hero Slider. Please add some.
         </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="flex justify-between items-center p-6 border-b border-black/10">
              <h2 className="text-xl font-serif">Add New Hero Image</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-black/50 hover:text-black">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-black/70 uppercase mb-1">Select Photo (16:9 recommended)</label>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={handleImageUpload} 
                  className="w-full border p-2 rounded mb-2 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#D4AF37]/10 file:text-[#b5952f] hover:file:bg-[#D4AF37]/20 transition" 
                />
                {isUploading && <p className="text-sm text-[#D4AF37] font-semibold mt-1">Optimizing image...</p>}
                
                {imagePreview && (
                  <div className="mt-3 relative w-full aspect-video border rounded-lg overflow-hidden">
                    <img src={imagePreview} className="w-full h-full object-cover" alt="Preview preview" />
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-black/10 mt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 border rounded font-semibold text-black/70 hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={isUploading} className="px-6 py-2 bg-[#1a1a1a] text-white rounded font-semibold hover:bg-black disabled:opacity-50">Upload</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
