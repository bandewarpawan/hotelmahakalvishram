import { useStore } from '../../store';
import { Eye, Check, X, Trash2 } from 'lucide-react';
import { format } from 'date-fns';

export default function AdminBookings() {
  const { bookings, updateBookingStatus, deleteBooking } = useStore();

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this booking permanently?')) {
      deleteBooking(id);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-serif text-[#1a1a1a] mb-8">Booking Management</h1>

      <div className="bg-white rounded-xl border border-black/10 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left font-sans text-sm">
            <thead className="bg-[#f8f5f0] text-black/60 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4 font-semibold">ID / Date</th>
                <th className="px-6 py-4 font-semibold">Guest Info</th>
                <th className="px-6 py-4 font-semibold">Room</th>
                <th className="px-6 py-4 font-semibold">Stay Dates</th>
                <th className="px-6 py-4 font-semibold">Status</th>
                <th className="px-6 py-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5">
              {bookings.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-12 text-black/40">No bookings found.</td></tr>
              ) : bookings.map((booking) => (
                <tr key={booking.id} className="hover:bg-black/[0.02] transition-colors">
                  <td className="px-6 py-4">
                    <p className="font-mono font-medium text-black">{booking.id}</p>
                    <p className="text-xs text-black/50">{format(new Date(booking.createdAt), 'MMM d, yy HH:mm')}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="font-semibold text-black">{booking.customerName}</p>
                    <p className="text-xs text-black/60">{booking.phone}</p>
                    <p className="text-xs text-black/50 mt-1">{booking.guests} Guests</p>
                  </td>
                  <td className="px-6 py-4 font-medium text-black/80">{booking.roomIdStr}</td>
                  <td className="px-6 py-4">
                    <p className="text-black/80">{format(new Date(booking.checkIn), 'MMM d, yyyy')}</p>
                    <p className="text-xs text-black/40 text-center">to</p>
                    <p className="text-black/80">{format(new Date(booking.checkOut), 'MMM d, yyyy')}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      booking.status === 'Confirmed' ? 'bg-green-100 text-green-700' : 
                      booking.status === 'Cancelled' ? 'bg-red-100 text-red-700' : 
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {booking.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right space-x-2">
                    {booking.status === 'Pending' && (
                      <button 
                        onClick={() => updateBookingStatus(booking.id, 'Confirmed')}
                        className="p-1.5 bg-green-100 text-green-700 hover:bg-green-200 rounded transition flex-inline items-center justify-center placeholder:title"
                        title="Confirm Booking"
                      >
                        <Check size={16} />
                      </button>
                    )}
                    {booking.status !== 'Cancelled' && (
                      <button 
                        onClick={() => updateBookingStatus(booking.id, 'Cancelled')}
                        className="p-1.5 bg-yellow-100 text-yellow-700 hover:bg-yellow-200 rounded transition flex-inline items-center justify-center"
                        title="Cancel Booking"
                      >
                        <X size={16} />
                      </button>
                    )}
                    <button 
                      onClick={() => handleDelete(booking.id)}
                      className="p-1.5 bg-red-100 text-red-700 hover:bg-red-200 rounded transition flex-inline items-center justify-center"
                      title="Delete Record"
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
