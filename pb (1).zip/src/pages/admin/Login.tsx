import React, { useState } from 'react';
import { useNavigate, Navigate, Link } from 'react-router-dom';
import { useStore } from '../../store';
import { auth } from '../../firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { Lock, Mail, Key, ArrowLeft } from 'lucide-react';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const isAdminLoggedIn = useStore(state => state.isAdminLoggedIn);
  const navigate = useNavigate();

  if (isAdminLoggedIn) {
    return <Navigate to="/admin" replace />;
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/admin');
    } catch (err: any) {
      setError(err.message || 'Failed to authenticate');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#1c2331] flex items-center justify-center p-4 relative">
      <Link 
        to="/" 
        className="absolute top-6 left-6 flex items-center gap-2 text-white/70 hover:text-white transition-colors"
      >
        <ArrowLeft size={20} />
        <span className="font-medium">Back to Website</span>
      </Link>
      
      <div className="bg-[#151a24] p-12 max-w-md w-full rounded-2xl shadow-2xl border border-white/10 relative">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-[#c48632]/20 rounded-full flex items-center justify-center mb-4 text-[#c48632]">
            <Lock size={32} />
          </div>
          <h1 className="text-3xl font-serif text-white">Admin Access</h1>
          <p className="text-white/50 text-sm uppercase tracking-widest mt-2">Restricted Area</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-4">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" size={20} />
              <input 
                type="email"
                placeholder="Admin Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/5 border border-white/10 text-white pl-10 pr-4 py-3 focus:outline-none focus:border-[#c48632] transition-colors rounded"
                required
              />
            </div>
            
            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" size={20} />
              <input 
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/5 border border-white/10 text-white pl-10 pr-4 py-3 focus:outline-none focus:border-[#c48632] transition-colors rounded tracking-widest"
                required
              />
            </div>
            {error && <p className="text-red-400 text-sm mt-3 text-center">{error}</p>}
          </div>
          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-[#c48632] hover:bg-[#a87127] disabled:opacity-50 text-white py-4 uppercase tracking-widest text-sm font-bold transition-colors rounded shadow-md"
          >
            {loading ? 'Authenticating...' : 'Authenticate'}
          </button>
        </form>
      </div>
    </div>
  );
}
