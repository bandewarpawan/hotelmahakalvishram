import { useStore } from '../../store';
import { BedDouble, CheckCircle2, CircleDashed } from 'lucide-react';
import { format } from 'date-fns';

export default function Dashboard() {
  const rooms = useStore(state => state.rooms);
  const bookings = useStore(state => state.bookings);

  const totalRooms = rooms.length;
  const bookedRooms = rooms.filter(r => r.status === 'Booked').length;
  const availableRooms = rooms.filter(r => r.status === 'Available').length;

  const recentBookings = bookings.slice(0, 5);

  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-serif mb-8 text-[#1a1a1a]">Overview</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white p-6 rounded-xl border border-black/5 flex items-center justify-between">
          <div>
            <p className="text-black/50 text-xs uppercase tracking-widest font-semibold mb-1">Total Rooms</p>
            <p className="text-4xl font-mono">{totalRooms}</p>
          </div>
          <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
            <BedDouble size={24} />
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-black/5 flex items-center justify-between">
          <div>
            <p className="text-black/50 text-xs uppercase tracking-widest font-semibold mb-1">Booked</p>
            <p className="text-4xl font-mono">{bookedRooms}</p>
          </div>
          <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center">
            <CheckCircle2 size={24} />
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-black/5 flex items-center justify-between">
          <div>
            <p className="text-black/50 text-xs uppercase tracking-widest font-semibold mb-1">Available</p>
            <p className="text-4xl font-mono">{availableRooms}</p>
          </div>
          <div className="w-12 h-12 rounded-full bg-green-50 text-green-600 flex items-center justify-center">
            <CircleDashed size={24} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-black/5 overflow-hidden">
        <div className="p-6 border-b border-black/5">
          <h2 className="text-xl font-serif">Recent Bookings</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left font-sans text-sm">
            <thead className="bg-[#f8f5f0] text-black/60 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4 font-semibold">Booking ID</th>
                <th className="px-6 py-4 font-semibold">Guest</th>
                <th className="px-6 py-4 font-semibold">Room</th>
                <th className="px-6 py-4 font-semibold">Dates</th>
                <th className="px-6 py-4 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5">
              {recentBookings.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-8 text-black/40">No recent bookings.</td></tr>
              ) : recentBookings.map((booking) => (
                <tr key={booking.id} className="hover:bg-black/[0.02] transition-colors">
                  <td className="px-6 py-4 font-mono font-medium">{booking.id}</td>
                  <td className="px-6 py-4">{booking.customerName}</td>
                  <td className="px-6 py-4">{booking.roomIdStr}</td>
                  <td className="px-6 py-4 text-black/60">
                    {format(new Date(booking.checkIn), 'MMM d')} - {format(new Date(booking.checkOut), 'MMM d, yyyy')}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      booking.status === 'Confirmed' ? 'bg-green-100 text-green-700' : 
                      booking.status === 'Cancelled' ? 'bg-red-100 text-red-700' : 
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {booking.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
