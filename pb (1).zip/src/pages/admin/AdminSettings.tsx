import { useStore } from '../../store';
import { useForm } from 'react-hook-form';
import { Settings } from '../../store';
import { Save } from 'lucide-react';
import { useState } from 'react';

export default function AdminSettings() {
  const { settings, updateSettings } = useStore();
  const [isSaved, setIsSaved] = useState(false);

  const { register, handleSubmit } = useForm<Settings>({
    defaultValues: settings
  });

  const onSubmit = (data: Settings) => {
    updateSettings(data);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="max-w-3xl">
      <h1 className="text-3xl font-serif text-[#1a1a1a] mb-8">System Settings</h1>

      <div className="bg-white rounded-xl border border-black/10 overflow-hidden shadow-sm">
        <form onSubmit={handleSubmit(onSubmit)} className="p-8 space-y-6">
          
          <div>
            <h3 className="text-lg font-serif border-b border-black/5 pb-2 mb-4">Hotel Information</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Hotel Name (English)</label>
                  <input {...register('hotelName', { required: true })} className="w-full border p-3 rounded bg-black/[0.02] focus:bg-white transition-colors" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Hotel Name (Hindi) - Optional</label>
                  <input {...register('hotelNameHi')} className="w-full border p-3 rounded bg-black/[0.02] focus:bg-white transition-colors" placeholder="उदा. महाकालेश्वर होटल" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Address (English)</label>
                  <textarea {...register('address', { required: true })} className="w-full border p-3 rounded bg-black/[0.02] focus:bg-white transition-colors h-24" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Address (Hindi) - Optional</label>
                  <textarea {...register('addressHi')} className="w-full border p-3 rounded bg-black/[0.02] focus:bg-white transition-colors h-24" placeholder="उदा. उज्जैन, मध्य प्रदेश" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-black/70 uppercase mb-1">Phone / WhatsApp Number</label>
                <input {...register('phone', { required: true })} className="w-full border p-3 rounded bg-black/[0.02] focus:bg-white transition-colors" />
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-serif border-b border-black/5 pb-2 mb-4 mt-8">Messaging & Features</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-black/70 uppercase mb-1">Default WhatsApp Message</label>
                <textarea {...register('whatsappMessage', { required: true })} className="w-full border p-3 rounded bg-black/[0.02] focus:bg-white transition-colors h-24" />
                <p className="text-xs text-black/40 mt-1">This message will be pre-filled when customers click "WhatsApp Us".</p>
              </div>

              <div className="flex items-center gap-3 bg-black/[0.02] p-4 rounded border">
                <input type="checkbox" id="ticketSystemEnabled" {...register('ticketSystemEnabled')} className="w-5 h-5 rounded text-[#D4AF37] focus:ring-[#D4AF37]" />
                <label htmlFor="ticketSystemEnabled" className="text-sm font-semibold text-black/80">Enable Ticket System (PDF Downloads)</label>
              </div>
            </div>
          </div>

          <div className="pt-8 flex items-center gap-4 border-t border-black/5">
            <button 
              type="submit"
              className="flex items-center gap-2 bg-[#1a1a1a] hover:bg-[#D4AF37] text-white px-8 py-3 rounded uppercase tracking-widest text-sm font-semibold transition-colors shadow-lg shadow-black/10"
            >
              <Save size={18} /> Save Settings
            </button>
            {isSaved && <span className="text-green-600 font-medium text-sm flex items-center gap-1">✔ Settings Saved!</span>}
          </div>
        </form>
      </div>
    </div>
  );
}
