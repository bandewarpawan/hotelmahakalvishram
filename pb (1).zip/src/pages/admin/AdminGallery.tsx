import React, { useState } from 'react';
import { useStore } from '../../store';
import { Plus, Trash2, X } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { compressImage } from '../../utils/imageUtils';

export default function AdminGallery() {
  const { gallery, addPhoto, deletePhoto } = useStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  
  const { register, handleSubmit, reset } = useForm();

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    setIsUploading(true);
    try {
      const dataUrl = await compressImage(e.target.files[0]);
      setImagePreview(dataUrl);
    } catch (error) {
      console.error("Error compressing image", error);
    }
    setIsUploading(false);
  };

  const onSubmit = (data: any) => {
    if (!imagePreview) {
      alert("Please select an image to upload");
      return;
    }
    addPhoto(imagePreview, data.caption, data.captionHi);
    reset();
    setImagePreview('');
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this photo from the gallery?')) {
      deletePhoto(id);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-serif text-[#1c2331]">Gallery Management</h1>
        <button 
          onClick={() => {
            setImagePreview('');
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 bg-[#1c2331] text-white px-4 py-2 rounded text-sm font-semibold hover:bg-black transition-colors"
        >
          <Plus size={16} /> Add Photo
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {gallery.map(photo => (
          <div key={photo.id} className="relative group bg-white p-2 rounded-xl border border-black/10 shadow-sm">
            {/* Standardizing to aspect-[4/3] to match Home.tsx unified sizing */}
            <div className="aspect-[4/3] relative overflow-hidden rounded-lg">
              <img src={photo.url} alt={photo.caption} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-[#1c2331]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                <button 
                  onClick={() => handleDelete(photo.id)}
                  className="w-10 h-10 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition shadow-lg"
                  title="Delete Photo"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
            <p className="mt-2 text-sm text-center font-medium text-[#1c2331]/70 truncate px-2">{photo.caption}</p>
            <p className="mt-1 text-xs text-center font-medium text-[#1c2331]/50 truncate px-2">{photo.captionHi}</p>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-[#1c2331]/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md border border-black/5">
            <div className="flex justify-between items-center p-6 border-b border-black/10 bg-[#fcfaf7] rounded-t-xl">
              <h2 className="text-xl font-serif text-[#1c2331]">Add New Photo</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-[#1c2331]/50 hover:text-red-500 transition-colors">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#1c2331]/70 uppercase mb-1 tracking-wide">Select Photo</label>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={handleImageUpload} 
                  className="w-full border p-2 rounded mb-2 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#c48632]/10 file:text-[#c48632] hover:file:bg-[#c48632]/20 shadow-sm transition" 
                />
                {isUploading && <p className="text-sm text-[#c48632] font-semibold mt-1">Processing image...</p>}
                
                {imagePreview && (
                  <div className="mt-4 relative w-full aspect-[4/3] border rounded-lg overflow-hidden shadow-inner">
                    <img src={imagePreview} className="w-full h-full object-cover" alt="Preview preview" />
                  </div>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#1c2331]/70 uppercase mb-1 tracking-wide">Caption (English)</label>
                  <input {...register('caption', { required: true })} placeholder="Pool side view" className="w-full border border-black/10 focus:border-[#c48632] outline-none p-3 rounded bg-white shadow-sm transition-colors" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#1c2331]/70 uppercase mb-1 tracking-wide">Caption (Hindi) - Opt</label>
                  <input {...register('captionHi')} placeholder="पूल के किनारे का नज़ारा" className="w-full border border-black/10 focus:border-[#c48632] outline-none p-3 rounded bg-white shadow-sm transition-colors" />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-black/10 mt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 border border-black/10 rounded font-semibold text-[#1c2331]/70 hover:bg-black/5 transition-colors">Cancel</button>
                <button type="submit" disabled={isUploading} className="px-6 py-2 bg-[#c48632] text-white rounded font-bold hover:bg-[#a87127] shadow-md transition-colors disabled:opacity-50">Upload Photo</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
