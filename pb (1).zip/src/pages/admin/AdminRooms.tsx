import React, { useState } from 'react';
import { useStore, Room } from '../../store';
import { Edit2, Trash2, Plus, X } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { compressImage } from '../../utils/imageUtils';

export default function AdminRooms() {
  const { rooms, addRoom, updateRoom, deleteRoom } = useStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const { register, handleSubmit, reset } = useForm<Omit<Room, 'id'>>();

  const openAddModal = () => {
    setEditingRoom(null);
    setImagePreviews([]);
    reset({ name: '', nameHi: '', price: 0, description: '', descriptionHi: '', size: '', amenities: [], amenitiesHi: [], images: [], status: 'Available' });
    setIsModalOpen(true);
  };

  const openEditModal = (room: Room) => {
    setEditingRoom(room);
    setImagePreviews(room.images || []);
    reset({
      name: room.name,
      nameHi: room.nameHi,
      price: room.price,
      description: room.description,
      descriptionHi: room.descriptionHi,
      size: room.size,
      amenities: room.amenities.join(', ') as any,
      amenitiesHi: room.amenitiesHi ? room.amenitiesHi.join(', ') as any : '',
      images: [], // Handled by imagePreviews state
      status: room.status
    });
    setIsModalOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    setIsUploading(true);
    const files = Array.from(e.target.files) as File[];
    const compressed: string[] = [];
    for (const file of files) {
      try {
        const dataUrl = await compressImage(file);
        compressed.push(dataUrl);
      } catch (error) {
        console.error("Error compressing image", error);
      }
    }
    setImagePreviews(prev => [...prev, ...compressed]);
    setIsUploading(false);
  };

  const removeImage = (index: number) => {
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const onSubmit = (data: any) => {
    const formattedData = {
      ...data,
      price: Number(data.price),
      amenities: typeof data.amenities === 'string' ? data.amenities.split(',').map((s:string) => s.trim()).filter(Boolean) : data.amenities,
      amenitiesHi: typeof data.amenitiesHi === 'string' ? data.amenitiesHi.split(',').map((s:string) => s.trim()).filter(Boolean) : data.amenitiesHi,
      images: imagePreviews, // Use uploaded images state
    };

    if (editingRoom) {
      updateRoom(editingRoom.id, formattedData);
    } else {
      addRoom(formattedData);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this room?')) {
      deleteRoom(id);
    }
  };

  const toggleStatus = (id: string, currentStatus: string) => {
    updateRoom(id, { status: currentStatus === 'Available' ? 'Booked' : 'Available' });
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-serif text-[#1a1a1a]">Room Management</h1>
        <button 
          onClick={openAddModal}
          className="flex items-center gap-2 bg-[#1a1a1a] text-white px-4 py-2 rounded text-sm font-semibold hover:bg-black transition-colors"
        >
          <Plus size={16} /> Add Room
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rooms.map(room => (
          <div key={room.id} className="bg-white rounded-xl border border-black/10 overflow-hidden flex flex-col shadow-sm">
            <div className="h-48 overflow-hidden relative">
              <img src={room.images[0] || 'https://via.placeholder.com/400'} alt={room.name} className="w-full h-full object-cover" />
              <button 
                onClick={() => toggleStatus(room.id, room.status)}
                className={`absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-bold shadow ${
                  room.status === 'Available' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
                }`}
              >
                {room.status}
              </button>
            </div>
            
            <div className="p-5 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl border-b border-black/10 pb-1 font-serif">{room.name}</h3>
                <span className="font-semibold text-[#D4AF37]">₹{room.price}</span>
              </div>
              <p className="text-sm text-black/60 mb-4 line-clamp-2">{room.description}</p>
              
              <div className="mt-auto flex justify-end gap-2 border-t border-black/5 pt-4">
                <button 
                  onClick={() => openEditModal(room)}
                  className="p-2 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                  title="Edit Room"
                >
                  <Edit2 size={18} />
                </button>
                <button 
                  onClick={() => handleDelete(room.id)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                  title="Delete Room"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b border-black/10 sticky top-0 bg-white">
              <h2 className="text-2xl font-serif">{editingRoom ? 'Edit Room' : 'Add New Room'}</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-black/50 hover:text-black">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Room Name (English)</label>
                  <input {...register('name', { required: true })} className="w-full border p-2 rounded" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Room Name (Hindi) - Optional</label>
                  <input {...register('nameHi')} className="w-full border p-2 rounded" placeholder="उदा. डीलक्स रूम" />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-bold text-black/70 uppercase mb-1">Price (₹)</label>
                <input type="number" {...register('price', { required: true, valueAsNumber: true })} className="w-full border p-2 rounded max-w-[200px]" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Description (English)</label>
                  <textarea {...register('description')} className="w-full border p-2 rounded h-24"></textarea>
                </div>
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Description (Hindi) - Optional</label>
                  <textarea {...register('descriptionHi')} className="w-full border p-2 rounded h-24"></textarea>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Room Size</label>
                  <input {...register('size')} placeholder="e.g. 300 sq ft" className="w-full border p-2 rounded" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Status</label>
                  <select {...register('status')} className="w-full border p-2 rounded">
                    <option value="Available">Available</option>
                    <option value="Booked">Booked</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Amenities (English, comma separated)</label>
                  <input {...register('amenities')} placeholder="AC, Free WiFi, TV" className="w-full border p-2 rounded" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-black/70 uppercase mb-1">Amenities (Hindi) - Optional</label>
                  <input {...register('amenitiesHi')} placeholder="एसी, मुफ्त वाईफाई, टीवी" className="w-full border p-2 rounded" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-black/70 uppercase mb-1">Room Images</label>
                <input 
                  type="file" 
                  multiple 
                  accept="image/*" 
                  onChange={handleImageUpload} 
                  className="w-full border p-2 rounded mb-3 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#D4AF37]/10 file:text-[#b5952f] hover:file:bg-[#D4AF37]/20 transition" 
                />
                {isUploading && <p className="text-sm text-[#D4AF37] mb-2 font-semibold">Processing images...</p>}
                
                <div className="flex flex-wrap gap-2">
                  {imagePreviews.map((imgUrl, idx) => (
                    <div key={idx} className="relative w-24 h-24 border border-black/10 rounded-lg overflow-hidden group">
                      <img src={imgUrl} className="w-full h-full object-cover" alt="Preview preview" />
                      <button 
                        type="button" 
                        onClick={() => removeImage(idx)}
                        className="absolute top-1 right-1 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                  {imagePreviews.length === 0 && !isUploading && (
                    <p className="text-black/40 text-sm italic w-full">No images selected</p>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t border-black/10">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 border rounded font-semibold text-black/70 hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-6 py-2 bg-[#1a1a1a] text-white rounded font-semibold hover:bg-black">Save Room</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
