import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { Check, ArrowLeft } from 'lucide-react';
import RoomImageSlider from '../components/RoomImageSlider';
import { t } from '../utils/translations';

export default function Rooms() {
  const { rooms, language } = useStore();
  const navigate = useNavigate();

  return (
    <div className="w-full bg-[#fcfaf7] min-h-screen">
      <div className="bg-[#1c2331] py-20 relative">
        <button 
          onClick={() => navigate(-1)}
          className="absolute top-8 left-4 md:left-8 z-50 bg-white/10 hover:bg-[#c48632] text-white px-5 py-2.5 rounded-full flex items-center gap-2 backdrop-blur-sm transition-all shadow-lg border border-white/20 text-sm font-semibold uppercase tracking-widest"
        >
          <ArrowLeft size={18} /> {t(language, 'back')}
        </button>
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="h-px bg-[#c48632]/30 w-24"></div>
            <h1 className="text-5xl md:text-6xl font-serif text-white">{t(language, 'selectYourStay')}</h1>
            <div className="h-px bg-[#c48632]/30 w-24"></div>
          </div>
          <p className="text-white/70 uppercase tracking-widest text-sm">{t(language, 'experienceComfort')}</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="grid grid-cols-1 gap-12">
          {rooms.map(room => (
            <div key={room.id} className="bg-white grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-0 shadow-lg rounded-xl overflow-hidden group transition-transform hover:-translate-y-1 border border-black/5">

              <div className="lg:col-span-3 relative h-64 md:h-full overflow-hidden block">
                <RoomImageSlider images={room.images} name={language === 'hi' && room.nameHi ? room.nameHi : room.name} />
              </div>
              <div className="lg:col-span-2 p-8 md:p-12 flex flex-col justify-center border-t md:border-t-0 md:border-l border-black/5">
                <div className="mb-6 flex justify-between items-start">
                  <h3 className="text-3xl font-serif text-[#1c2331]">{language === 'hi' && room.nameHi ? room.nameHi : room.name}</h3>
                  <div className="text-right">
                    <p className="text-3xl font-sans font-bold text-[#c48632]">₹{room.price}</p>
                    <p className="text-xs uppercase tracking-wider text-[#1c2331]/50">{language === 'hi' ? 'प्रति रात्रि' : 'per night'}</p>
                  </div>
                </div>

                <p className="text-[#1c2331]/70 font-sans mb-8 leading-relaxed">
                  {language === 'hi' && room.descriptionHi ? room.descriptionHi : room.description}
                </p>

                <div className="mb-8 font-sans">
                  <p className="text-xs font-bold uppercase tracking-widest mb-3 text-[#1c2331]">{t(language, 'features')}</p>
                  <ul className="grid grid-cols-2 gap-2 text-sm text-[#1c2331]/80">
                    {(language === 'hi' && room.amenitiesHi ? room.amenitiesHi : room.amenities).slice(0, 4).map(amenity => (
                      <li key={amenity} className="flex items-center gap-2 font-medium">
                        <Check size={16} className="text-[#c48632]" /> {amenity}
                      </li>
                    ))}
                  </ul>
                </div>


                <div className="flex items-center justify-between mt-auto">
                  <div className="font-sans">
                      {room.status === 'Available' ? (
                        <span className="flex items-center gap-2 text-emerald-600 text-sm font-bold uppercase tracking-wider">
                          <span className="w-2 h-2 rounded-full bg-emerald-600"></span> Available
                        </span>
                      ) : (
                        <span className="flex items-center gap-2 text-red-600 text-sm font-bold uppercase tracking-wider">
                          <span className="w-2 h-2 rounded-full bg-red-600"></span> Booked
                        </span>
                      )}
                  </div>
                  <Link 
                    to={`/rooms/${room.id}`} 
                    className="inline-block bg-[#1c2331] hover:bg-[#c48632] text-white px-8 py-3 rounded-md uppercase tracking-widest text-xs font-semibold transition-colors shadow-md"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
