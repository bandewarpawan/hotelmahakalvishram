import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useStore } from '../store';
import { Check, ChevronLeft, ChevronRight, User, Phone, Users, ArrowLeft } from 'lucide-react';
import { t } from '../utils/translations';

export default function RoomDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const rooms = useStore(state => state.rooms);
  const addBooking = useStore(state => state.addBooking);
  const language = useStore(state => state.language);
  const room = rooms.find(r => r.id === id);

  const [currentImage, setCurrentImage] = useState(0);

  const { register, handleSubmit, formState: { errors } } = useForm();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (!room) {
    return <div className="min-h-screen flex items-center justify-center">Room not found</div>;
  }

  const nextImage = () => {
    setCurrentImage((prev) => (prev + 1) % room.images.length);
  };

  const prevImage = () => {
    setCurrentImage((prev) => (prev - 1 + room.images.length) % room.images.length);
  };

  const onSubmit = (data: any) => {
    const bookingId = addBooking({
      roomId: room.id,
      roomIdStr: room.name,
      customerName: data.customerName,
      phone: data.phone,
      checkIn: data.checkIn,
      checkOut: data.checkOut,
      guests: parseInt(data.guests, 10),
    });
    
    navigate(`/booking/${bookingId}/ticket`);
  };

  return (
    <div className="w-full bg-[#fcfaf7] min-h-screen relative">
      {/* Back Button explicitly floating on top of the Room Detail */}
      <button 
        onClick={() => navigate(-1)}
        className="absolute top-8 left-4 md:left-8 z-50 bg-[#1c2331]/60 hover:bg-[#c48632] text-white px-5 py-2.5 rounded-full flex items-center gap-2 backdrop-blur-sm transition-all shadow-xl border border-white/20"
      >
        <ArrowLeft size={18} /> {t(language, 'back')}
      </button>

      {/* Image Slider Header */}
      <div className="relative h-[60vh] md:h-[75vh] w-full bg-[#1c2331] group">
        <img 
          src={room.images[currentImage] || 'https://via.placeholder.com/1200x800'} 
          alt={language === 'hi' && room.nameHi ? room.nameHi : room.name} 
          className="w-full h-full object-cover transition-opacity duration-500"
        />
        
        {room.images.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-[#1c2331]/40 hover:bg-[#1c2331]/80 text-white rounded-full flex items-center justify-center backdrop-blur-sm transition-all shadow-lg"
            >
              <ChevronLeft size={24} />
            </button>
            <button 
              onClick={nextImage}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-[#1c2331]/40 hover:bg-[#1c2331]/80 text-white rounded-full flex items-center justify-center backdrop-blur-sm transition-all shadow-lg"
            >
              <ChevronRight size={24} />
            </button>

            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-30">
              {room.images.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImage(index)}
                  className={`w-2 h-2 rounded-full transition-all shadow-md ${currentImage === index ? 'bg-[#c48632] w-6' : 'bg-white/70 hover:bg-white'}`}
                />
              ))}
            </div>
          </>
        )}
        
        {/* Dark overlay to ensure text/buttons visibility if needed */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/20 pointer-events-none"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          
          {/* Room Details */}
          <div className="lg:col-span-2">
            <div className="flex justify-between items-start mb-8 border-b border-black/5 pb-8">
              <div>
                <p className="text-[#c48632] uppercase tracking-widest text-sm font-semibold mb-2">{t(language, 'roomDetails')}</p>
                <h1 className="text-4xl md:text-5xl font-serif text-[#1c2331]">{language === 'hi' && room.nameHi ? room.nameHi : room.name}</h1>
              </div>
              <div className="text-right">
                <p className="text-4xl font-sans font-bold text-[#c48632]">₹{room.price}</p>
                <p className="text-xs uppercase tracking-wider text-[#1c2331]/50 font-semibold mt-1">{language === 'hi' ? 'प्रति रात्रि' : 'per night'}</p>
              </div>
            </div>

            <div className="prose prose-lg text-[#1c2331]/70 mb-12 font-sans font-medium leading-relaxed">
              <p>{language === 'hi' && room.descriptionHi ? room.descriptionHi : room.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-8 mb-12 py-8 border-y border-black/5 bg-white rounded-lg p-6 shadow-sm">
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-[#1c2331]/50 mb-1">{t(language, 'size')}</p>
                <p className="text-lg text-[#1c2331] font-semibold">{room.size}</p>
              </div>
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-[#1c2331]/50 mb-1">Status</p>
                <p className={`text-lg font-bold ${room.status === 'Available' ? 'text-emerald-600' : 'text-red-600'}`}>
                  {room.status === 'Available' ? t(language, 'statusAvailable') : t(language, 'statusBooked')}
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-serif mb-6 text-[#1c2331]">{t(language, 'features')}</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(language === 'hi' && room.amenitiesHi ? room.amenitiesHi : room.amenities).map(amenity => (
                  <li key={amenity} className="flex items-center gap-3 text-[#1c2331]/80 font-medium bg-white p-3 rounded-lg shadow-sm border border-black/5">
                    <Check size={18} className="text-[#c48632]" /> {amenity}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Booking Form */}
          <div className="lg:col-span-1">
            <div className="bg-white p-8 rounded-xl shadow-lg border border-black/5 sticky top-32">
              <h3 className="text-2xl font-serif text-[#1c2331] mb-6 border-b border-black/5 pb-4">{t(language, 'bookThisRoom')}</h3>
              
              {room.status === 'Booked' ? (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md font-medium text-center">
                  {language === 'hi' ? 'क्षमा करें, यह कमरा वर्तमान में बुक है।' : 'Sorry, this room is currently booked.'}
                </div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#1c2331]/70 font-bold mb-2">{t(language, 'name')}</label>
                    <div className="relative">
                      <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#1c2331]/40" />
                      <input 
                        {...register('customerName', { required: true })}
                        className="w-full bg-[#fcfaf7] border border-black/10 rounded-md px-10 py-3 text-sm focus:outline-none focus:border-[#c48632] focus:ring-1 focus:ring-[#c48632] transition-colors"
                        placeholder="John Doe"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#1c2331]/70 font-bold mb-2">{t(language, 'phone')}</label>
                    <div className="relative">
                      <Phone size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#1c2331]/40" />
                      <input 
                        {...register('phone', { required: true })}
                        className="w-full bg-[#fcfaf7] border border-black/10 rounded-md px-10 py-3 text-sm focus:outline-none focus:border-[#c48632] focus:ring-1 focus:ring-[#c48632] transition-colors"
                        placeholder="+91 98765 43210"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-[#1c2331]/70 font-bold mb-2">{t(language, 'checkIn')}</label>
                      <div className="relative">
                        <input 
                          type="date"
                          {...register('checkIn', { required: true })}
                          className="w-full bg-[#fcfaf7] border border-black/10 rounded-md px-3 py-3 text-sm focus:outline-none focus:border-[#c48632] focus:ring-1 focus:ring-[#c48632] transition-colors"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-[#1c2331]/70 font-bold mb-2">{t(language, 'checkOut')}</label>
                      <div className="relative">
                        <input 
                          type="date"
                          {...register('checkOut', { required: true })}
                          className="w-full bg-[#fcfaf7] border border-black/10 rounded-md px-3 py-3 text-sm focus:outline-none focus:border-[#c48632] focus:ring-1 focus:ring-[#c48632] transition-colors"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#1c2331]/70 font-bold mb-2">{t(language, 'guests')}</label>
                    <div className="relative">
                      <Users size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#1c2331]/40" />
                      <select 
                        {...register('guests', { required: true })}
                        className="w-full bg-[#fcfaf7] border border-black/10 rounded-md px-10 py-3 text-sm focus:outline-none focus:border-[#c48632] focus:ring-1 focus:ring-[#c48632] transition-colors appearance-none"
                      >
                        <option value="1">1 Person</option>
                        <option value="2">2 People</option>
                        <option value="3">3 People</option>
                        <option value="4">4 People</option>
                      </select>
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-[#1c2331] hover:bg-[#c48632] text-white py-4 mt-6 rounded-md uppercase tracking-widest text-sm font-bold transition-all shadow-lg transform hover:-translate-y-0.5"
                  >
                    {t(language, 'confirmBooking')}
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
