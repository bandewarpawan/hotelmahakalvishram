import { useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useStore } from '../store';
import { Download, Share2, ArrowLeft } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { format } from 'date-fns';

export default function Ticket() {
  const { id } = useParams();
  const bookings = useStore(state => state.bookings);
  const settings = useStore(state => state.settings);
  
  const booking = bookings.find(b => b.id === id);
  const ticketRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (!booking) {
    return <div className="min-h-screen flex items-center justify-center">Ticket not found</div>;
  }

  const handleDownload = async () => {
    if (!ticketRef.current) return;
    
    try {
      const canvas = await html2canvas(ticketRef.current, { scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: 'a4'
      });
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`Booking-${booking.id}.pdf`);
    } catch (error) {
      console.error('Error generating PDF', error);
    }
  };

  const shareOnWhatsApp = () => {
    const text = `*Booking Confirmed at ${settings.hotelName}*
    
*Booking ID:* ${booking.id}
*Name:* ${booking.customerName}
*Room:* ${booking.roomIdStr}
*Check-in:* ${booking.checkIn}
*Check-out:* ${booking.checkOut}
*Guests:* ${booking.guests}

Looking forward to your stay!`;

    const encodedText = encodeURIComponent(text);
    window.open(`https://wa.me/?text=${encodedText}`, '_blank');
  };

  return (
    <div className="w-full bg-[#f8f5f0] min-h-screen py-16 px-4">
      <div className="max-w-2xl mx-auto">
        <Link 
          to="/" 
          className="inline-flex items-center gap-2 text-sm uppercase tracking-widest text-black/60 hover:text-[#D4AF37] mb-8 transition-colors no-print"
        >
          <ArrowLeft size={16} /> Back to Home
        </Link>

        {/* Ticket Card */}
        <div 
          ref={ticketRef} 
          className="bg-white p-8 md:p-12 shadow-2xl relative overflow-hidden mb-8 border border-black/5"
        >
          {/* Decorative Pattern */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/10 rounded-bl-full -z-0"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#D4AF37]/10 rounded-tr-full -z-0"></div>

          <div className="relative z-10 text-center mb-10 pb-8 border-b border-dashed border-black/20">
            <h1 className="text-3xl font-serif text-[#1a1a1a] mb-2">{settings.hotelName}</h1>
            <p className="text-black/60 font-sans text-sm">{settings.address}</p>
            <p className="text-black/60 font-sans text-sm">{settings.phone}</p>
          </div>

          <div className="relative z-10 mb-10 text-center">
            <p className="text-xs uppercase tracking-[0.2em] text-black/50 mb-2 font-bold">Booking ID</p>
            <p className="text-4xl font-mono font-bold tracking-wider">{booking.id}</p>
          </div>

          <div className="relative z-10 grid grid-cols-2 gap-y-8 gap-x-4 mb-4">
            <div>
              <p className="text-xs uppercase tracking-widest text-black/50 mb-1">Guest Name</p>
              <p className="font-semibold text-lg">{booking.customerName}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest text-black/50 mb-1">Room</p>
              <p className="font-semibold text-lg">{booking.roomIdStr}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest text-black/50 mb-1">Check-In</p>
              <p className="font-semibold">{format(new Date(booking.checkIn), 'dd MMM yyyy')}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest text-black/50 mb-1">Check-Out</p>
              <p className="font-semibold">{format(new Date(booking.checkOut), 'dd MMM yyyy')}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest text-black/50 mb-1">Guests</p>
              <p className="font-semibold">{booking.guests} Person(s)</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest text-black/50 mb-1">Phone</p>
              <p className="font-semibold">{booking.phone}</p>
            </div>
          </div>
          
          <div className="relative z-10 border-t border-dashed border-black/20 pt-8 mt-4 text-center">
             <p className="text-xs text-black/40 uppercase tracking-widest">Thank you for choosing us</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center no-print">
          <button 
            onClick={handleDownload}
            className="flex items-center justify-center gap-2 bg-[#1a1a1a] hover:bg-black text-white px-8 py-4 uppercase tracking-widest text-sm font-semibold transition-colors"
          >
            <Download size={18} /> Download Ticket
          </button>
          <button 
            onClick={shareOnWhatsApp}
            className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white px-8 py-4 uppercase tracking-widest text-sm font-semibold transition-colors"
          >
            <Share2 size={18} /> Share on WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
}
