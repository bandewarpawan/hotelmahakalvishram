import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { Wifi, Wind, Coffee, Car, X } from 'lucide-react';
import { useState } from 'react';
import HeroSlider from '../components/HeroSlider';
import RoomImageSlider from '../components/RoomImageSlider';
import ReviewSection from '../components/ReviewSection';
import { t } from '../utils/translations';

export default function Home() {
  const { settings, rooms, gallery, heroImages, language } = useStore();
  const featuredRooms = rooms.slice(0, 3);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const currentHotelName = language === 'hi' && settings.hotelNameHi ? settings.hotelNameHi : settings.hotelName;

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-[85vh] w-full bg-[#1c2331] flex items-center justify-center overflow-hidden">
        <HeroSlider images={heroImages} interval={4000} />
        <div className="absolute inset-0 bg-black/40 z-10 pointer-events-none" />
        <div className="relative z-20 text-center px-4 max-w-4xl pointer-events-auto">
          <p className="text-white/90 uppercase tracking-[0.2em] mb-4 text-sm font-semibold drop-shadow-md">{t(language, 'experienceComfort')}</p>
          <h1 className="text-5xl md:text-7xl lg:text-8xl text-white mb-8 leading-[0.9] drop-shadow-lg font-serif">{language === 'en' ? 'Welcome to' : 'स्वागत है'} <span className="italic">{currentHotelName}</span></h1>
          <Link 
            to="/rooms" 
            className="inline-block bg-[#c48632] hover:bg-[#a87127] text-white px-10 py-4 rounded-md shadow-lg shadow-[#c48632]/20 font-semibold transition-all transform hover:-translate-y-1"
          >
            {t(language, 'checkAvailability')}
          </Link>
        </div>
      </section>

      {/* About Section */}
      <section className="py-24 bg-[#fcfaf7] relative z-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="h-px bg-[#c48632]/30 w-24"></div>
            <h2 className="text-4xl md:text-5xl font-serif text-[#1c2331]">{t(language, 'aboutUs')}</h2>
            <div className="h-px bg-[#c48632]/30 w-24"></div>
          </div>
          <p className="text-sm uppercase tracking-widest text-[#c48632] mb-8 font-semibold">{t(language, 'experienceBest')}</p>
          <p className="text-lg md:text-xl text-[#1c2331]/70 leading-relaxed mb-16 font-medium max-w-3xl mx-auto">
            {language === 'en' ? `Welcome to ${settings.hotelName}. We provide top-notch amenities and exceptional service to make your stay unforgettable.` : `${currentHotelName} में आपका स्वागत है। हम आपके प्रवास को अविस्मरणीय बनाने के लिए बेहतरीन सुविधाएँ और असाधारण सेवा प्रदान करते हैं।`}
          </p>
          
          <div className="flex items-center justify-center gap-4 mb-4 mt-8">
            <div className="h-px bg-[#c48632]/30 w-16"></div>
            <h3 className="text-2xl font-serif text-[#1c2331]">{t(language, 'ourAmenities')}</h3>
            <div className="h-px bg-[#c48632]/30 w-16"></div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-12">
            <div className="flex flex-col items-center gap-3">
              <div className="text-[#c48632]"><Wind size={32} /></div>
              <span className="text-sm font-semibold text-[#1c2331]">{t(language, 'freeWifi')}</span>
            </div>
            <div className="flex flex-col items-center gap-3">
              <div className="text-[#c48632]"><Wifi size={32} /></div>
              <span className="text-sm font-semibold text-[#1c2331]">{t(language, 'restaurant')}</span>
            </div>
            <div className="flex flex-col items-center gap-3">
              <div className="text-[#c48632]"><Car size={32} /></div>
              <span className="text-sm font-semibold text-[#1c2331]">{t(language, 'pool')}</span>
            </div>
            <div className="flex flex-col items-center gap-3">
              <div className="text-[#c48632]"><Coffee size={32} /></div>
              <span className="text-sm font-semibold text-[#1c2331]">{t(language, 'roomService')}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Rooms Preview */}
      <section className="py-24 bg-white relative z-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="h-px bg-[#c48632]/30 w-24"></div>
              <h2 className="text-4xl md:text-5xl font-serif text-[#1c2331]">{t(language, 'ourRooms')}</h2>
              <div className="h-px bg-[#c48632]/30 w-24"></div>
            </div>
            <p className="text-lg text-[#1c2331]/60">{t(language, 'chooseStay')}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredRooms.map((room, index) => (
              <div key={room.id} className="bg-[#fcfaf7] border border-black/5 flex flex-col h-full shadow-lg rounded-t-lg overflow-hidden">
                <div className="relative h-64 overflow-hidden z-20">
                  <RoomImageSlider images={room.images} name={language === 'hi' && room.nameHi ? room.nameHi : room.name} />
                  {room.status === 'Booked' && (
                    <div className="absolute top-4 right-4 bg-red-600 text-white text-xs uppercase tracking-wider px-3 py-1 font-bold z-30 pointer-events-none rounded">
                      {t(language, 'statusBooked')}
                    </div>
                  )}
                </div>
                <div className="p-8 text-center flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-2xl mb-4 font-serif text-[#1c2331] hover:text-[#c48632] transition-colors"><Link to={`/rooms/${room.id}`}>{language === 'hi' && room.nameHi ? room.nameHi : room.name}</Link></h3>
                    <p className="text-[#1c2331]/60 text-sm mb-6 line-clamp-3 px-4">{language === 'hi' && room.descriptionHi ? room.descriptionHi : room.description}</p>
                  </div>
                  <Link to={`/rooms/${room.id}`} className="bg-[#1c2331] hover:bg-[#2a3447] text-white px-6 py-2.5 rounded shadow-md text-sm font-semibold transition-colors mt-auto mx-auto w-fit">
                    {t(language, 'viewDetails')}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-24 bg-[#fcfaf7] relative z-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-center gap-4 mb-16">
            <div className="h-px bg-[#c48632]/30 w-16"></div>
            <h2 className="text-4xl font-serif text-[#1c2331]">{t(language, 'photoGallery')}</h2>
            <div className="h-px bg-[#c48632]/30 w-16"></div>
          </div>
          {/* Ensure all images are uniform size */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {gallery.slice(0, 8).map((photo) => (
              <div 
                key={photo.id} 
                className="relative group overflow-hidden aspect-[4/3] rounded-lg shadow-sm cursor-pointer"
                onClick={() => setSelectedImage(photo.url)}
              >
                <img 
                  src={photo.url} 
                  alt={language === 'hi' && photo.captionHi ? photo.captionHi : photo.caption} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-[#1c2331]/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <p className="text-white font-serif text-lg text-center px-2 shadow-sm">{language === 'hi' && photo.captionHi ? photo.captionHi : photo.caption}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fullscreen Lightbox for Gallery */}
      {selectedImage && (
        <div className="fixed inset-0 z-[100] bg-[#1c2331]/95 flex items-center justify-center p-4 backdrop-blur-md" onClick={() => setSelectedImage(null)}>
          <button 
            onClick={(e) => { e.stopPropagation(); setSelectedImage(null); }}
            className="absolute top-6 right-6 bg-white/10 hover:bg-red-500 text-white rounded-full p-3 transition-colors z-[110] shadow-lg"
          >
            <X size={32} />
          </button>
          <img 
            src={selectedImage} 
            alt="Fullscreen View" 
            className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl" 
            onClick={(e) => e.stopPropagation()} 
          />
        </div>
      )}

      {/* Reviews Section */}
      <ReviewSection />

    </div>
  );
}
