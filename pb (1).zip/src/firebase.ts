import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyD41NfQOOyyoW_OlicuydXx1ISf-ZgWbXI",
  authDomain: "b2b-adedc.firebaseapp.com",
  databaseURL: "https://b2b-adedc-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "b2b-adedc",
  storageBucket: "b2b-adedc.firebasestorage.app",
  messagingSenderId: "19643579115",
  appId: "1:19643579115:web:4421aa22aa500658efdcae"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
